
# PMCSN - Settembre 2024

**Autore:** Pieraldo Santurro (Matricola: 0353517)

## Progetto

Progetto di modellazione, simulazione ed analisi di un sistema basato su un'assistenza clienti telefonica.

## Linguaggio

**Python**

## Struttura del Codice

Il codice è organizzato nella cartella `model`, che contiene diverse sottocartelle, ognuna specifica per una parte della simulazione. Ogni sottocartella contiene tre file principali:

- **main**: il file principale che esegue la simulazione.
- **functions**: contiene funzioni ausiliarie, strutture di aggregazione e misurazione.
- **parameters**: contiene i parametri modificabili per la simulazione.

### Cartelle di Simulazione

- **Validation Sim**: Simulazione utilizzata nella fase iniziale di Validazione e Verifica.
- **Transient Sim**: Simulazione utilizzata nella fase di studio del transitorio.
- **Steady State Sim**: Simulazione utilizzata nella fase di studio a transitorio esaurito.
- **Cost Sim**: Simulazione utilizzata per l'analisi giornaliera, settimanale ed annuale con calcolo del costo di simulazione.

All'interno di ogni cartella di simulazione verranno create, se non già presenti, le seguenti sottocartelle:

- **csv**: contiene i risultati dell'analisi in formato CSV.
- **images**: contiene i grafici ottenuti dalle simulazioni in formato PNG.

## Comandi

È necessaria l'installazione di Python e della libreria `matplotlib`. 

Comando per l'installazione:

```bash
pip install matplotlib
```

### Esecuzione delle Simulazioni

Per avviare una simulazione, posizionarsi nella cartella `model` e utilizzare uno dei seguenti comandi:

```bash
python3 -m validation_sim.main
```

```bash
python3 -m transient_sim.main
```

```bash
python3 -m steady_state_sim.main
```

```bash
python3 -m cost_sim.main
```

## Contatti

Per qualsiasi chiarimento, contattare:  
**Email:** santurro.pieraldo99@gmail.com
