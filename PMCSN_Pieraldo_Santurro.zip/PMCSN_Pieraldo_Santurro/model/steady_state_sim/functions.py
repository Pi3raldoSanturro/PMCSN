

from utils.rngs import random, selectStream, plantSeeds
from utils.rvgs import Exponential, TruncatedNormal, BoundedPareto, Normal
from steady_state_sim.parameters import *


class Track:
    node = 0.0  # time integrated number in the node
    queue = 0.0  # time integrated number in the queue
    service = 0.0  # time integrated number in service

    def __init__(self):
        self.node = 0.0
        self.queue = 0.0
        self.service = 0.0


class Time:
    current = None  # current time
    next = None  # next (most imminent) event time




class BasicQueue:
    id = None
    arrival = None  # next arrival time
    completion = None  # next completion time
    last = 0.0  # last arrival time
    index = 0.0  # jobs departed
    index_support = 0.0  # ci serve per tenere traccia di tutti i job processati
    number = 0.0  # jobs in node
    stat = None

    def __init__(self, id_node):
        self.id = id_node
        self.stat = Track()  # Track stats


def exit_from_bot():
    selectStream(select_exit_from_bot)
    r = random()
    if r <= p_exit_bot:
        return True
    else:
        return False


def set_arrival_time(x):
    global arrival_time
    arrival_time = x


def get_arrival_time():
    return arrival_time


def minimum(a, b):
    if a is None and b is not None:
        return b
    elif b is None and a is not None:
        return a
    elif a is None and b is None:
        return None
    elif a < b:
        return a
    else:
        return b


def next_event():
    time_event = []
    for i in range(1, len(node_list)):
        time_event.append(node_list[i].arrival)
        time_event.append(node_list[i].completion)

    time_event = sorted(time_event, key=lambda x: (x is None, x))

    for i in range(1, len(time_event)):
        if time_event[0] == node_list[i].arrival or time_event[0] == node_list[i].completion:
            return i


def get_arrival(y):
    selectStream(select_node_arrival)
    return Exponential(y)


# def get_service(id_node, alpha_bot, alpha_sm, alpha_op):
#     if id_node == BOT:  
#         selectStream(select_node_random)
#         r = random()
#         if r <= p_longer_service:  # Probabilità che un job abbia bisogno di un tempo di servizio maggiore
#             selectStream(id_node + select_bot_stream)
#             return BoundedPareto(alpha_bot, p=2.0, k=1.0)  # Tempo di servizio del bot (60-120 secondi)
#         else:
#             selectStream(id_node + select_bot_stream)
#             return BoundedPareto(alpha_sm, p=5, k=1.0)  # Tempo di smistamento verso un operatore (1-5 minuti)
#     else:  # Operatori umani
#         selectStream(id_node + select_operator)
#         return BoundedPareto(alpha_op, p=10, k=3)  # Tempo di servizio degli operatori (3-10 minuti)

def get_service(id_node):
    if id_node == BOT:  # Il bot del call center
        selectStream(select_node_random)
        r = random()
        if r <= p_longer_service:  # Probabilità che un job abbia bisogno di un tempo di servizio maggiore
            selectStream(id_node + select_bot_stream)
            service = Normal(m=1.5, s=0.25)  # Tempo medio 1.5 minuti con deviazione standard di 0.25 minuti
            return service
        else:
            selectStream(id_node + select_bot_stream)
            service = Normal(m=4.0, s=1.0)  # Tempo medio 4 minuti con deviazione standard di 1 minuto
            return service
    else:  # Operatori umani
        selectStream(id_node + select_operator)
        service = Normal(m=7.5, s=2.0)  # Tempo medio 7.5 minuti con deviazione standard di 2 minuti
        return service



def online_variance(n, mean, variance, x):
    delta = x - mean
    variance = variance + delta * delta * (n - 1) / n
    mean = mean + delta / n
    return mean, variance
