import os
import csv


from scipy.stats import pearsonr
import statistics
from math import sqrt

from matplotlib import pyplot as plt

from utils.rngs import random, selectStream, plantSeeds
from utils.rvgs import Exponential, TruncatedNormal, BoundedPareto
from utils.rvms import idfStudent

from steady_state_sim.parameters import arrival_time
from steady_state_sim.parameters import select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream, select_exit_from_bot 
from steady_state_sim.parameters import b,k,START,STOP, INFINITY
from steady_state_sim.parameters import p_longer_service, p_exit_bot
from steady_state_sim.parameters import NODES_min, NODES_max

from steady_state_sim.functions import Track, BasicQueue, Time
from steady_state_sim.functions import exit_from_bot, set_arrival_time, get_arrival_time, minimum, online_variance, get_arrival, get_service


BOT = 1


seeds = [987654321, 539458255, 482548808,
         1757116804, 238927874, 841744376,
         1865511657, 482548808, 430131813, 725267564]


file_dir = os.path.dirname(__file__)
png_dir = os.path.join(file_dir, './images')



def next_event():
    time_event = []
    for i in range(1, len(node_list)):
        time_event.append(node_list[i].arrival)
        time_event.append(node_list[i].completion)

    time_event = sorted(time_event, key=lambda x: (x is None, x))

    for i in range(1, len(time_event)):
        if time_event[0] == node_list[i].arrival or time_event[0] == node_list[i].completion:
            return i

def select_node(id_node):
    selectStream(select_node_stream)
    if id_node:
        r = random()
        for i in range(1, NODES):
            if r <= i / (NODES - 1):
                return i + 1
    return BOT


def plot_stats_global(number_of_nodes, png_dir):
    fig, axs = plt.subplots(2, 1, figsize=(16, 9), dpi=400)
    x = [str(info_list[i]["seed"]) for i in range(0, len(info_list))]
    y = [info_list[i]["final_wait_system"] for i in range(0, len(info_list))]
    plt.xticks(rotation=45)
    axs[0].set_ylabel(ylabel="Avg wait system (minutes)", fontsize=15)
    axs[0].tick_params(labelsize=10)

    axs[0].errorbar(x, y, yerr=[info_list[i]["final_w_system"] for i in range(0, len(info_list))], fmt='.',
                    color='blue', ecolor='red', elinewidth=3, capsize=0)

    axs[0].set_xlabel(xlabel="Seed", fontsize=15)

    cellText = []
    for j in range(len(info_list)):
        row = []
        row.append(str(info_list[j]["seed"]))
        row.append(str(info_list[j]["final_wait_system"]))
        row.append(str(info_list[j]["final_std_system"]))
        row.append("±" + str(info_list[j]["final_w_system"]))
        row.append("95%")
        cellText.append(row)

    cols = ("seed", "media", "deviazione standard", "intervallo di confidenza", "confidence level")
    axs[1].axis('tight')
    axs[1].axis('off')
    axs[1].table(cellText=cellText, cellLoc='center', colLabels=cols, loc='center')

    if not os.path.exists(png_dir):
        os.makedirs(png_dir)

    plt.savefig(fname=f"{png_dir}/plot_stats_global_result_nodes_{number_of_nodes}.png", bbox_inches='tight')
    plt.close(fig)  # Chiudi la figura


def plot_stats_bot(number_of_nodes, png_dir):
    fig, axs = plt.subplots(2, 1, figsize=(16, 9), dpi=400)
    x = [str(info_list[i]["seed"]) for i in range(0, len(info_list))]
    y = [info_list[i]["final_delay_bot"] for i in range(0, len(info_list))]
    plt.xticks(rotation=45)
    axs[0].set_ylabel(ylabel="Avg delay bot node (minutes)", fontsize=15)
    axs[0].tick_params(labelsize=10)

    axs[0].errorbar(x, y, yerr=[info_list[i]["final_w_bot"] for i in range(0, len(info_list))], fmt='.',
                    color='blue',
                    ecolor='red', elinewidth=3, capsize=0)

    axs[0].set_xlabel(xlabel="Seed", fontsize=15)

    cellText = []
    for j in range(len(info_list)):
        row = []
        row.append(str(info_list[j]["seed"]))
        row.append(str(info_list[j]["final_delay_bot"]))
        row.append(str(info_list[j]["final_std_bot"]))
        row.append("±" + str(info_list[j]["final_w_bot"]))
        row.append("95%")
        cellText.append(row)

    cols = ("seed", "media", "deviazione standard", "intervallo di confidenza", "confidence level")
    axs[1].axis('tight')
    axs[1].axis('off')
    axs[1].table(cellText=cellText,
                 cellLoc='center',
                 colLabels=cols,
                 loc='center')

    if not os.path.exists(png_dir):
        os.makedirs(png_dir)

    plt.savefig(fname=f"{png_dir}/plot_stats_bot_result_nodes_{number_of_nodes}.png", bbox_inches='tight')
    plt.close(fig)  # Chiudi la figura


def plot_delay_human_nodes(number_of_nodes, png_dir):
    fig, ax = plt.subplots(figsize=(16, 9), dpi=400)
    x = [i for i in range(0, len(main_structure["avg_delay_human_nodes"]))]
    y = main_structure["avg_delay_human_nodes"][:]

    ax.errorbar(x, y, fmt='.', color='black', ecolor='red', elinewidth=3, capsize=0)

    ax.legend(["Gain"])
    ax.set_title("Avg delay of all system")
    ax.set_xlabel("Configuration")
    ax.set_ylabel("Gain function")

    x1 = [i for i in range(0, len(job_list))]
    y1 = [i["delay_human_nodes"] for i in job_list]
    ax.errorbar(x1, y1, fmt='.')

    fig.tight_layout()  # Applica tight_layout all'oggetto Figure

    if not os.path.exists(png_dir):
        os.makedirs(png_dir)

    plt.savefig(fname=f"{png_dir}/plot_delay_human_nodes_result_{number_of_nodes}.png", bbox_inches='tight')
    plt.close(fig)  # Chiudi la figura

def plot_final_w_human_nodes_confidence_interval(final_results, png_dir):
    # Estrai i dati dal dizionario final_results
    number_of_nodes = []
    final_w_human_nodes = []
    
    for result in final_results:
        number_of_nodes.append(result['number_of_nodes'])
        final_w_human_nodes.append(result['final_w_human_nodes'])
    
    # Crea il grafico
    plt.figure(figsize=(10, 6))
    plt.plot(number_of_nodes, final_w_human_nodes, marker='o', linestyle='-', color='green')
    
    plt.xlabel('Number of Nodes', fontsize=14)
    plt.ylabel('Final W Human Nodes (Confidence Interval Width)', fontsize=14)
    plt.title('Final W Human Nodes Confidence Interval x Number of Nodes', fontsize=16)
    
    plt.grid(True)
    
    if not os.path.exists(png_dir):
        os.makedirs(png_dir)
    
    plt.savefig(os.path.join(png_dir, "final_w_human_nodes_vs_number_of_nodes.png"), bbox_inches='tight')
    plt.close()



def plot_final_wait_of_system(final_results, png_dir):
    # Estrai i dati dal dizionario final_results
    number_of_nodes = []
    final_wait_system = []
    
    for result in final_results:
        number_of_nodes.append(result['number_of_nodes'])
        final_wait_system.append(result['final_wait_system'])
    
    # Crea il grafico
    plt.figure(figsize=(10, 6))
    plt.plot(number_of_nodes, final_wait_system, marker='o', linestyle='-', color='red')
    
    plt.xlabel('Number of Nodes', fontsize=14)
    plt.ylabel('Final Wait of System', fontsize=14)
    plt.title('Final Wait of System x Number of Nodes', fontsize=16)
    
    plt.grid(True)

    if not os.path.exists(png_dir):
        os.makedirs(png_dir)
    
    plt.savefig(os.path.join(png_dir, "final_wait_system_vs_number_of_nodes.png"), bbox_inches='tight')
    plt.close()

def plot_final_w_system_confidence_interval(final_results, png_dir):
    # Estrai i dati dal dizionario final_results
    number_of_nodes = []
    final_w_system = []
    
    for result in final_results:
        number_of_nodes.append(result['number_of_nodes'])
        final_w_system.append(result['final_w_system'])
    
    # Crea il grafico
    plt.figure(figsize=(10, 6))
    plt.plot(number_of_nodes, final_w_system, marker='o', linestyle='-', color='orange')
    
    plt.xlabel('Number of Nodes', fontsize=14)
    plt.ylabel('Final Wait of System Confidence Interval', fontsize=14)
    plt.title('Final Wait of System Confidence Interval x Number of Nodes', fontsize=16)
    
    plt.grid(True)
    
    if not os.path.exists(png_dir):
        os.makedirs(png_dir)

    plt.savefig(os.path.join(png_dir, "final_w_system_confidence_interval_vs_number_of_nodes.png"), bbox_inches='tight')
    plt.close()



def plot_final_delay_human_nodes(final_results, png_dir):
    # Estrai i dati dal dizionario final_results
    number_of_nodes = []
    final_delay_human_nodes = []
    
    for result in final_results:
        number_of_nodes.append(result['number_of_nodes'])
        final_delay_human_nodes.append(result['final_delay_human_nodes'])
    
    # Crea il grafico
    plt.figure(figsize=(10, 6))
    plt.plot(number_of_nodes, final_delay_human_nodes, marker='o', linestyle='-', color='blue')
    
    plt.xlabel('Number of Nodes', fontsize=14)
    plt.ylabel('Final Delay Human Nodes', fontsize=14)
    plt.title('Final Delay Human Nodes vs. Number of Nodes', fontsize=16)
    
    plt.grid(True)
    
    if not os.path.exists(png_dir):
        os.makedirs(png_dir)
    
    plt.savefig(os.path.join(png_dir, "final_delay_human_nodes_vs_number_of_nodes.png"), bbox_inches='tight')
    plt.close()


def plot_correlation(number_of_nodes, png_dir):
    if not info_list:
        print("info_list è vuoto!")
        return

    colors = ['red', 'royalblue', 'green', 'lawngreen', 'lightseagreen', 'orange', 'blueviolet']

    # print(f"Info list length: {len(info_list)}")
    # print(f"Colors length: {len(colors)}")

    x = [i for i in range(0, len(info_list[0]["correlation_delay_human_nodes"]))]

    plt.xticks(rotation=45)
    plt.rcParams["figure.figsize"] = (16, 9)

    for i in range(0, len(info_list)):
        color = colors[i % len(colors)]  # Usa i colori ciclicamente
        # print(f"Plotting for seed: {info_list[i]['seed']}")
        plt.plot(x, info_list[i]["correlation_delay_human_nodes"], 'o',
                 linestyle='--', color=color, label=info_list[i]["seed"], mfc='none')

    plt.xlabel("Lag")
    plt.ylabel("Correlation wait system")

    if not os.path.exists(png_dir):
        os.makedirs(png_dir)

    plt.savefig(fname=f"{png_dir}/plot_correlation_result_{number_of_nodes}.png", bbox_inches='tight')
    plt.close()  # Chiudi la figura

def debug_print_final_variables(final_results):
    print("Debugging Final Results Structure:\n")
    for result in final_results:
        print(f"Number of Nodes: {result['number_of_nodes']}")
        print(f"Final Delay Bot: {result['final_delay_bot']:.4f}")
        print(f"Final Delay Human Nodes: {result['final_delay_human_nodes']:.4f}")
        print(f"Final Wait System: {result['final_wait_system']:.4f}")
        print(f"Final Std Bot: {result['final_std_bot']:.4f}")
        print(f"Final Std Human Nodes: {result['final_std_human_nodes']:.4f}")
        print(f"Final Std System: {result['final_std_system']:.4f}")
        print(f"Final W Bot (Confidence Interval Width): {result['final_w_bot']:.4f}")
        print(f"Final W Human Nodes (Confidence Interval Width): {result['final_w_human_nodes']:.4f}")
        print(f"Final W System (Confidence Interval Width): {result['final_w_system']:.4f}")
        print("-" * 50)  # Linea divisoria per separare i risultati di diverse simulazioni



time = Time()
info_list = []
final_results = []

if __name__ == '__main__':
    for number_of_nodes in range(NODES_min, NODES_max + 1):
        NODES = number_of_nodes
        info_list = [] 
        for seed in seeds:
            batch_index = 0
            job_list = []

            # settings
            structure_sample = {
                "seed": 0,
                "number_of_nodes": 0,
                "lambda": 0.0,
                "b": 0,
                "k": 0,
                "avg_wait_system": [],
                "avg_delay_bot": [],
                "avg_delay_human_nodes": [],
                "final_delay_bot": 0.0,
                "final_std_bot": 0.0,
                "final_w_bot": 0.0,
                "final_delay_human_nodes": 0.0,
                "final_std_human_nodes": 0.0,
                "final_w_human_nodes": 0.0,
                "final_wait_system": 0.0,
                "final_std_system": 0.0,
                "final_w_system": 0.0,
                "correlation_delay_human_nodes": []
            }
            main_structure = structure_sample
            main_structure["seed"] = seed
            main_structure["b"] = b
            main_structure["k"] = k
            main_structure["number_of_nodes"] = NODES - 1
            main_structure["lambda"] = 1.0 / arrival_time
            node_list = [BasicQueue(i) for i in range(NODES + 1)]  # in 0 global stats
            plantSeeds(seed)

            time.current = START
            arrival = START  # global temp var for getArrival function     [minutes]

            # initialization of the first arrival event
            arrival += get_arrival(arrival_time)
            node = node_list[select_node(False)]
            node.arrival = arrival
            min_arrival = arrival
            old_index = 0
            old_batch_current = START

            while node_list[0].index_support <= b * (k - 1):  # (node_list[0].number > 0)
                if node_list[0].index % b == 0 and node_list[0].index != 0:  # and old_index != node_list[0].index:
                    human_nodes_counter = 0  # all completed jobs from standard
                    human_nodes_counter_total = 0
                    for element in node_list:
                        if element.id > BOT:
                            human_nodes_counter += element.index
                            human_nodes_counter_total += element.index_support
                    human_nodes_counter = int(human_nodes_counter)
                    human_nodes_counter_total = int(human_nodes_counter_total)
                    old_index = node_list[0].index
                    avg_delay_bot = job_list[human_nodes_counter_total + human_nodes_counter - 1]["delay_bot"]  # prendo l'ultimo elemento
                    avg_delay_human_nodes = job_list[human_nodes_counter_total + human_nodes_counter - 1][
                        "delay_human_nodes"]  # che rappresenta la media sul
                    avg_wait_system = job_list[human_nodes_counter_total + human_nodes_counter - 1]["wait_system"]


                    for element in node_list:
                        element.index_support += element.index
                        element.index = 0.0
                        element.stat.node = 0.0
                        element.stat.queue = 0.0
                        element.stat.service = 0.0

                    main_structure["avg_delay_bot"].append(avg_delay_bot)
                    main_structure["avg_delay_human_nodes"].append(avg_delay_human_nodes)
                    main_structure["avg_wait_system"].append(avg_wait_system)
                    batch_index += 1
                    old_batch_current = time.current

                node_to_process = node_list[next_event()] 
                time.next = minimum(node_to_process.arrival, node_to_process.completion)
                # Aggiornamento delle aree basate sul giro prima
                for i in range(0, len(node_list)):
                    if node_list[i].number > 0:
                        # if i == 0 or i == node_to_process.id:
                        node_list[i].stat.node += (time.next - time.current) * node_list[i].number
                        node_list[i].stat.queue += (time.next - time.current) * (node_list[i].number - 1)
                        node_list[i].stat.service += (time.next - time.current)

                current_for_update = time.current
                time.current = time.next  # advance the clock

                if time.current == node_to_process.arrival:

                    node_to_process.number += 1
                    node_list[0].number += 1  # update system stat
                    arrival += get_arrival(arrival_time)
                    node_selected_pos = select_node(False)

                    # Se il prossimo arrivo è su un altro centro, bisogna eliminare l'arrivo sul centro processato altrimenti
                    # sarà sempre il minimo
                    if node_selected_pos != node_to_process.id:
                        node_to_process.arrival = INFINITY
                    node = node_list[node_selected_pos]

                    if node.arrival != INFINITY:
                        node.last = node.arrival
                        if node.last is not None and node_list[0].last is not None and node_list[0].last < node.last:
                            node_list[0].last = node.last
                    # update node and system last arrival time

                    # Controllo che l'arrivo sul nodo i-esimo sia valido. In caso negativo
                    # imposto come ultimo arrivo del nodo i-esimo l'arrivo precedentemente
                    # considerato
                    if arrival > STOP:
                        if node.arrival != INFINITY:
                            node.last = node.arrival
                        # update node and system last arrival time
                        if node_list[0].last < node.last:
                            node_list[0].last = node.last
                        node.arrival = INFINITY
                    else:
                        node.arrival = arrival

                    if node_to_process.number == 1:
                        node_to_process.completion = time.current + get_service(node_to_process.id)
                else:
                    node_to_process.index += 1  # node stats update
                    node_to_process.number -= 1
                    if node_to_process.id != BOT:  # system stats update
                        node_list[0].index += 1
                        node_list[0].number -= 1

                        #  Inserimento statistiche puntuali ad ogni completamento
                        actual_stats = {
                            "delay_bot": 0.0,
                            "delay_human_nodes": 0.0,
                            "wait_system": 0.0
                        }
                        act_st = actual_stats
                        if node_list[0].index != 0:
                            act_st["wait_system"] = node_list[0].stat.node / node_list[0].index
                        if node_list[1].index != 0:
                            act_st["delay_bot"] = node_list[1].stat.queue / node_list[1].index
                        delay_human_nodes_avg = 0
                        for i in range(2, NODES + 1):
                            if node_list[i].index != 0:
                                delay_human_nodes_avg += (node_list[i].stat.queue / node_list[i].index)
                        delay_human_nodes_avg = delay_human_nodes_avg / (NODES - 1.0)
                        act_st["delay_human_nodes"] = delay_human_nodes_avg
                        job_list.append(act_st)

                    if node_to_process.number > 0:
                        node_to_process.completion = time.current + get_service(node_to_process.id)
                    else:
                        node_to_process.completion = INFINITY

                    if node_to_process.id == BOT:  
                        if not exit_from_bot():
                            human_node_element = node_list[select_node(True)]  # on first global stats


                            human_node_element.number += 1  # system stats don't updated
                            human_node_element.last = time.current

                            if human_node_element.number == 1:
                                human_node_element.completion = time.current + get_service(human_node_element.id)
                        else:
                            node_list[0].index += 1
                            node_list[0].number -= 1

                arrival_list = [node_list[n].arrival for n in range(1, len(node_list))]
                min_arrival = sorted(arrival_list, key=lambda x: (x is None, x))[0]
            # print(time.current)
            #  Global batch means
            for i in range(0, 10):
                main_structure["correlation_delay_human_nodes"].append(
                    pearsonr(main_structure["avg_wait_system"][:k - i],
                             main_structure["avg_wait_system"][i:])[0])
            final_avg_delay_bot = 0.0
            final_avg_delay_human_nodes = 0.0
            final_std_bot = 0.0
            final_std_human_nodes = 0.0
            final_avg_wait_system = 0.0
            final_std_system = 0.0
            n = 0
            for i in range(4, len(main_structure["avg_delay_bot"])):
                n += 1
                #  avg calculation,  std calculation
                final_avg_delay_bot, final_std_bot = online_variance(n, final_avg_delay_bot, final_std_bot,main_structure["avg_delay_bot"][i])
                final_avg_delay_human_nodes, final_std_human_nodes = online_variance(n, final_avg_delay_human_nodes,final_std_human_nodes,main_structure["avg_delay_human_nodes"][i])
                final_avg_wait_system, final_std_system = online_variance(n, final_avg_wait_system, final_std_system,main_structure["avg_wait_system"][i])
                                                                          

            final_std_bot = statistics.variance(main_structure["avg_delay_bot"][4:])
            final_std_human_nodes = statistics.variance(main_structure["avg_delay_human_nodes"][4:])
            final_std_system = statistics.variance(main_structure["avg_wait_system"][4:])

            final_std_bot = sqrt(final_std_bot)
            final_std_human_nodes = sqrt(final_std_human_nodes)
            final_std_system = sqrt(final_std_system)
            #  calculate interval width
            LOC = 0.95
            u = 1.0 - 0.5 * (1.0 - LOC)  # interval parameter
            t = idfStudent(n - 1, u)  # critical value of t
            final_w_bot = t * final_std_bot / sqrt(n - 1)  # interval half width
            final_w_human_nodes = t * final_std_human_nodes / sqrt(n - 1)  # interval half width
            final_w_system = t * final_std_system / sqrt(n - 1)  # interval half width
            main_structure["final_delay_bot"] = final_avg_delay_bot
            main_structure["final_delay_human_nodes"] = final_avg_delay_human_nodes
            main_structure["final_std_bot"] = final_std_bot
            main_structure["final_std_human_nodes"] = final_std_human_nodes
            main_structure["final_w_bot"] = final_w_bot
            main_structure["final_w_human_nodes"] = final_w_human_nodes
            main_structure["final_wait_system"] = final_avg_wait_system
            main_structure["final_std_system"] = final_std_system
            main_structure["final_w_system"] = final_w_system


            info_list.append(main_structure)
            
            # Directory per i file CSV
            csv_dir = os.path.join(file_dir, './csv')

            # Nel loop, per ogni seme (seed)
            path = os.path.join(csv_dir, "stats_" + str(seed) + ".csv")

            # Estrai la directory dal percorso (in caso volessi controllare)
            directory = os.path.dirname(path)

            # Controlla se la directory esiste, in caso contrario, creala
            if not os.path.exists(directory):
                os.makedirs(directory)

            # Definisci i nomi dei campi per il file CSV
            fieldnames = list(main_structure.keys())

            # Apri il file CSV e scrivi i dati
            with open(path, 'w', newline='') as csv_file:
                writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerow(main_structure)

        #  Salva le variabili finali per ogni numero di nodi nella struttura globale
        final_results.append({
            "number_of_nodes": number_of_nodes,
            "final_delay_bot": final_avg_delay_bot,
            "final_delay_human_nodes": final_avg_delay_human_nodes,
            "final_wait_system": final_avg_wait_system,
            "final_std_bot": final_std_bot,
            "final_std_human_nodes": final_std_human_nodes,
            "final_std_system": final_std_system,
            "final_w_bot": final_w_bot,
            "final_w_human_nodes": final_w_human_nodes,
            "final_w_system": final_w_system
        })

        plot_stats_global(number_of_nodes, png_dir)         # OK
        plot_stats_bot(number_of_nodes, png_dir)            # OK
        plot_delay_human_nodes(number_of_nodes, png_dir)    # Nulla

        avg_wait_system = 0.0
        for i in range(0, len(info_list)):
            avg_wait_system += info_list[i]["final_wait_system"]
            avg_wait_system = avg_wait_system / len(info_list)
        
        

        plot_correlation(number_of_nodes, png_dir)          # OK


    debug_print_final_variables(final_results)
    plot_final_delay_human_nodes(final_results, png_dir)
    plot_final_w_human_nodes_confidence_interval(final_results, png_dir)
    plot_final_wait_of_system(final_results, png_dir)
    plot_final_w_system_confidence_interval(final_results, png_dir)
