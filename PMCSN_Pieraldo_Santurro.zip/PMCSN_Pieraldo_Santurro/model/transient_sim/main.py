
import csv
import os
from math import sqrt
from matplotlib import pyplot as plt

from utils.rngs import random, selectStream, plantSeeds, getSeed
from utils.rvgs import Exponential, BoundedPareto
from utils.rvms import idfStudent

from transient_sim.functions import Track, Time, BasicQueue
from transient_sim.functions import online_variance, set_arrival_time, get_arrival_time, get_arrival, exit_from_bot, next_event, select_node, minimum, get_service

from transient_sim.parameters import NODES, arrival_time, select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream, select_exit_from_bot
from transient_sim.parameters import seeds
from transient_sim.parameters import b, k, START, STOP, INFINITY, BOT
from transient_sim.parameters import p_longer_service, p_exit_bot

from transient_sim.parameters import replicas, sampling_frequency


def plot_stats_transient_sim(node_number, info_list):
    x = [i * sampling_frequency for i in range(0, len(info_list[0]["avg_wait_system"]))]
    colors = ['red', 'royalblue', 'green', 'lawngreen', 'lightseagreen', 'orange', 'blueviolet']
    
    plt.figure(figsize=(16, 9), dpi=400)
    plt.rc('axes', labelsize=20)
    plt.rc('legend', fontsize=5)
    plt.rc('xtick', labelsize=15)
    plt.rc('ytick', labelsize=15)

    for i in range(len(info_list)):
        plt.plot(x, [info_list[i]["avg_wait_system"][j] for j in range(len(info_list[i]["avg_wait_system"]))],
                 'o', color=colors[i % len(colors)], label=info_list[i]["seed"], mfc='none')
    plt.legend([f"seed = {entry['seed']}" for entry in info_list])

    plt.xlabel("Number of jobs")
    plt.ylabel("Avg wait system (minutes)")
    script_dir = os.path.dirname(__file__)
    results_dir = os.path.join(script_dir, '../transient_sim/images/')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)

    plt.savefig(fname=results_dir + "/sys_stats_with" + str(node_number) + "_nodes", bbox_inches='tight')
    plt.close()

    # Plot for 'avg_delay_Human_Nodes'
    x = [i * sampling_frequency for i in range(0, len(info_list[0]["avg_delay_Human_Nodes"]))]
    
    plt.figure(figsize=(16, 9), dpi=400)
    plt.rc('axes', labelsize=20)
    plt.rc('legend', fontsize=5)
    plt.rc('xtick', labelsize=15)
    plt.rc('ytick', labelsize=15)

    for i in range(len(info_list)):
        plt.plot(x, info_list[i]["avg_delay_Human_Nodes"], 'o', color=colors[i % len(colors)], label=info_list[i]["seed"], mfc='none')
    plt.legend(["seed = " + str(info_list[i]["seed"]) for i in range(len(info_list))])

    plt.xlabel("Number of jobs")
    plt.ylabel("Avg delay Human Nodes (minutes)")
    plt.savefig(fname=results_dir + "/avg_delay_human_nodes_with_" + str(node_number) + "_nodes", bbox_inches='tight')
    plt.close()

    # Plot for 'avg_wait_of_bot_node'
    plt.figure(figsize=(16, 9), dpi=400)
    for i in range(len(info_list)):
        plt.plot(x, info_list[i]["avg_wait_of_BOT_node"], 'o', color=colors[i % len(colors)], label=info_list[i]["seed"], mfc='none')
    plt.legend(["seed = " + str(info_list[i]["seed"]) for i in range(len(info_list))])

    plt.xlabel("Number of jobs")
    plt.ylabel("Avg wait of BOT node (minutes)")
    plt.savefig(fname=results_dir + "/avg_wait_of_bot_node_with_" + str(node_number) + "_nodes", bbox_inches='tight')
    plt.close()


def plot_confidence_intervals(node_number, simulation_set, replicas):

    results_dir = os.path.join(script_dir, '../transient_sim/images/')

    if replicas > 1:
        # Plot for 'w_BOT'
        plt.figure(figsize=(16, 9), dpi=400)
        plt.plot(range(len(simulation_set["w_BOT"])), simulation_set["w_BOT"], 'o-', label='w_BOT')
        plt.xlabel("Index")
        plt.ylabel("w_BOT")
        plt.title("Confidence Interval Width for BOT")
        plt.legend()
        plt.savefig(fname=results_dir + "/w_BOT_" + str(node_number) + "_nodes", bbox_inches='tight')
        plt.close()

        # Plot for 'w_Human_Nodes'
        plt.figure(figsize=(16, 9), dpi=400)
        plt.plot(range(len(simulation_set["w_Human_Nodes"])), simulation_set["w_Human_Nodes"], 'o-', label='w_Human_Nodes')
        plt.xlabel("Index")
        plt.ylabel("w_Human_Nodes")
        plt.title("Confidence Interval Width for Human Nodes")
        plt.legend()
        plt.savefig(fname=results_dir + "/w_Human_Nodes_" + str(node_number) + "_nodes", bbox_inches='tight')
        plt.close()

        # Plot for 'w_system'
        plt.figure(figsize=(16, 9), dpi=400)
        plt.plot(range(len(simulation_set["w_system"])), simulation_set["w_system"], 'o-', label='w_system')
        plt.xlabel("Index")
        plt.ylabel("w_system")
        plt.title("Confidence Interval Width for System")
        plt.legend()
        plt.savefig(fname=results_dir + "/w_system_" + str(node_number) + "_nodes", bbox_inches='tight')
        plt.close()


def simulazione_transiente(seed, NODES, arrival_time):
    info_list = []
    simulation_set = {
        "seed": seed,
        "NODES": NODES - 1,
        "lambda": 1.0 / arrival_time,
        "b": b,
        "k": k,
        "job_list": [],
        "avg_wait_of_BOT_node": [],
        "st_dev_BOT": [],
        "w_BOT": [],
        "avg_delay_Human_Nodes": [],
        "st_dev_Human_Nodes": [],
        "w_Human_Nodes": [],
        "avg_wait_system": [],
        "st_dev_system": [],
        "w_system": [],
        "correlation_of_Human_Nodes": 0.0
    }

    node_list = [BasicQueue(i) for i in range(NODES + 1)]
    plantSeeds(seed)

    for replica in range(replicas):
        job_list = []
        simulation_set["job_list"] = job_list
        for center in node_list:
            center.number = 0.0
            center.last = 0.0
            center.arrival = None
            center.completion = None
            center.index = 0.0
            center.stat.node = 0.0
            center.stat.queue = 0.0
            center.stat.service = 0.0

        index = 0
        time = Time()
        time.current = START
        arrival = START

        arrival += get_arrival(arrival_time)
        node = node_list[select_node(False)]
        node.arrival = arrival
        min_arrival = arrival
        old_index = 0

        while node_list[0].index <= b * k:
            if node_list[0].index % sampling_frequency == 0 and node_list[0].index != 0 and old_index != node_list[0].index:
                old_index = node_list[0].index

                old_index_human_centers = 0
                for center in node_list:
                    if center.id > BOT:
                        old_index_human_centers += center.index
                old_index_human_centers = int(old_index_human_centers)

                if replica == 0:
                    simulation_set["avg_wait_of_BOT_node"].append(job_list[old_index_human_centers - 1]["wait_Bot"])
                    simulation_set["st_dev_BOT"].append(0.0)

                    simulation_set["avg_delay_Human_Nodes"].append(job_list[old_index_human_centers - 1]["delay_Human"])
                    simulation_set["st_dev_Human_Nodes"].append(0.0)

                    simulation_set["avg_wait_system"].append(job_list[old_index_human_centers - 1]["wait_system"])
                    simulation_set["st_dev_system"].append(0.0)
                else:
                    simulation_set["avg_wait_of_BOT_node"][index], simulation_set["st_dev_BOT"][index] = online_variance(
                        replica + 1,
                        simulation_set["avg_wait_of_BOT_node"][index],
                        simulation_set["st_dev_BOT"][index],
                        job_list[old_index_human_centers - 1]["wait_Bot"])
                    simulation_set["avg_delay_Human_Nodes"][index], simulation_set["st_dev_Human_Nodes"][index] = online_variance(
                        replica + 1,
                        simulation_set["avg_delay_Human_Nodes"][index],
                        simulation_set["st_dev_Human_Nodes"][index],
                        job_list[old_index_human_centers - 1]["delay_Human"])
                    simulation_set["avg_wait_system"][index], simulation_set["st_dev_system"][index] = online_variance(
                        replica + 1,
                        simulation_set["avg_wait_system"][index],
                        simulation_set["st_dev_system"][index],
                        job_list[old_index_human_centers - 1]["wait_system"])

                index += 1

            node_to_process = node_list[next_event(node_list)]
            time.next = minimum(node_to_process.arrival, node_to_process.completion)
            for i in range(len(node_list)):
                if node_list[i].number > 0:
                    node_list[i].stat.node += (time.next - time.current) * node_list[i].number
                    node_list[i].stat.queue += (time.next - time.current) * (node_list[i].number - 1)
                    node_list[i].stat.service += (time.next - time.current)

            time.current = time.next

            if time.current == node_to_process.arrival:
                node_to_process.number += 1
                node_list[0].number += 1
                arrival += get_arrival(arrival_time)
                node_selected_pos = select_node(False)

                if node_selected_pos != node_to_process.id:
                    node_to_process.arrival = INFINITY
                node = node_list[node_selected_pos]

                if node.arrival != INFINITY:
                    node.last = node.arrival
                    if node.last is not None and node_list[0].last is not None and node_list[0].last < node.last:
                        node_list[0].last = node.last

                if arrival > STOP:
                    if node.arrival != INFINITY:
                        node.last = node.arrival
                    if node_list[0].last < node.last:
                        node_list[0].last = node.last
                    node.arrival = INFINITY
                else:
                    node.arrival = arrival

                if node_to_process.number == 1:
                    node_to_process.completion = time.current + get_service(node_to_process.id)
            else:
                node_to_process.index += 1
                node_to_process.number -= 1
                if node_to_process.id != BOT:
                    node_list[0].index += 1
                    node_list[0].number -= 1

                    actual_stats = {
                        "wait_Bot": 0.0,
                        "delay_Human": 0.0,
                        "wait_system": 0.0
                    }
                    act_st = actual_stats
                    if node_list[0].index != 0:
                        act_st["wait_system"] = node_list[0].stat.node / node_list[0].index
                    if node_list[1].index != 0:
                        act_st["wait_Bot"] = node_list[1].stat.node / node_list[1].index
                    delay_Human_avg = 0.0
                    for i in range(2, NODES + 1):
                        if node_list[i].index != 0:
                            delay_Human_avg += (node_list[i].stat.queue / node_list[i].index)
                    delay_Human_avg = delay_Human_avg / (NODES - 1.0)
                    act_st["delay_Human"] = delay_Human_avg
                    job_list.append(act_st)

                if node_to_process.number > 0:
                    node_to_process.completion = time.current + get_service(node_to_process.id)
                else:
                    node_to_process.completion = INFINITY

                if node_to_process.id == BOT:
                    if not exit_from_bot():
                        human_node = node_list[select_node(True)]
                        human_node.number += 1
                        human_node.last = time.current

                        if human_node.number == 1:
                            human_node.completion = time.current + get_service(human_node.id)
                    else:
                        node_list[0].index += 1
                        node_list[0].number -= 1

            arrival_list = [node_list[n].arrival for n in range(1, len(node_list))]
            min_arrival = sorted(arrival_list, key=lambda x: (x is None, x))[0]

        if len(seeds) <= 5:
            new_seed = getSeed()
            seeds.append(new_seed)
    
    for i in range(len(simulation_set["st_dev_Human_Nodes"])):
        simulation_set["st_dev_Human_Nodes"][i] = sqrt(simulation_set["st_dev_Human_Nodes"][i] / replicas)
        simulation_set["st_dev_BOT"][i] = sqrt(simulation_set["st_dev_BOT"][i] / replicas)
        simulation_set["st_dev_system"][i] = sqrt(simulation_set["st_dev_system"][i] / replicas)
        if replicas > 1:
            LOC = 0.95
            u = 1.0 - 0.5 * (1.0 - LOC)
            t = idfStudent(replicas - 1, u)
            w_BOT = t * simulation_set["st_dev_BOT"][i] / sqrt(replicas - 1)
            w_Human_Nodes = t * simulation_set["st_dev_Human_Nodes"][i] / sqrt(replicas - 1)
            w_system = t * simulation_set["st_dev_system"][i] / sqrt(replicas - 1)
            simulation_set["w_BOT"].append(w_BOT)
            simulation_set["w_Human_Nodes"].append(w_Human_Nodes)
            simulation_set["w_system"].append(w_system)

    return simulation_set


info_list = []
time = Time()


if __name__ == '__main__':
    script_dir = os.path.dirname(__file__)
    results_dir = os.path.join(script_dir, '../transient_sim/csv')
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)


    for seed in seeds:
        simulation_set = simulazione_transiente(seed, NODES, arrival_time)
        info_list.append(simulation_set)

        path = os.path.join(results_dir, f"stats_{seed}.csv")
        with open(path, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(simulation_set.keys())
            writer.writerow(simulation_set.values())

        plot_confidence_intervals(NODES, simulation_set, replicas)

    plot_stats_transient_sim(NODES, info_list)

