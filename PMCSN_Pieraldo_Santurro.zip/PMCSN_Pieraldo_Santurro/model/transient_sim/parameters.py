
# Parametri globali


NODES = 2  # numero di nodi
arrival_time = 6.3
select_node_stream = 11
select_node_arrival = 10
select_node_random = 23
select_operator = 150
select_bot_stream = 100
select_exit_from_bot = 55

seeds = [2121212121]

b = 128  # b*k = n -> number of jobs
k = 64
START = 0
STOP = 1000 * 12 * 28 * 1440.0  # Minutes
INFINITY = STOP * 100.0
BOT = 1
p_longer_service = 0.6
p_exit_bot = 0.1


replicas = 128
sampling_frequency = 75