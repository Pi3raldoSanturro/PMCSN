
# Parametri globali - Validation_sim
NODES = 5  # n nodi

arrival_time_morning = 3.8
arrival_time_afternoon = 4.8
arrival_time_evening = 6.3
arrival_time_night = 11.0

select_node_stream = 11
select_node_arrival = 10
select_node_random = 23
select_operator = 150
select_bot_stream = 100
select_exit_from_bot = 55

seed = 212121212
START = 0
STOP = 10 * 12 * 30 * 1440.0
INFINITY = STOP * 100.0
BOT = 1
p_longer_service = 0.6
p_exit_bot = 0.1






