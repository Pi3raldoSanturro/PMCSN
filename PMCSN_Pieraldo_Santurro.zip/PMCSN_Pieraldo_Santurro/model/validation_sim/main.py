from validation_sim.functions import run_simulation
from validation_sim.parameters import *



if __name__ == '__main__':
    run_simulation(NODES, arrival_time_morning, arrival_time_afternoon, arrival_time_evening, arrival_time_night,
                   select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream,
                   select_exit_from_bot, seed, START, STOP, INFINITY, BOT, p_longer_service, p_exit_bot)
