from utils.rngs import random, selectStream, plantSeeds
from utils.rvgs import Exponential, Normal
from validation_sim.parameters import *


# Tracciamento delle statistiche
class Track:
    node = 0.0          
    queue = 0.0         
    service = 0.0       

    def __init__(self):
        self.node = 0.0
        self.queue = 0.0
        self.service = 0.0

# Implementazione del Clock corrente e prossimo
class Time:
    current = None          # current time
    next = None             # next (most imminent) event time

# Coda
class BasicQueue:
    id = None
    arrival = None  # next arrival time
    completion = None  # next completion time
    last = 0.0  # last arrival time
    index = 0.0  # jobs departed
    number = 0.0  # jobs in node
    stat = None

    def __init__(self, id_node):
        self.id = id_node
        self.stat = Track()  # Track stats

### Funzioni ausiliarie

def online_variance(n, mean, variance, x):
    delta = x - mean
    variance = variance + delta * delta * (n - 1) / n
    mean = mean + delta / n
    return mean, variance

def set_arrival_time(x):
    global arrival_time
    arrival_time = x

def get_arrival_time():
    return arrival_time

def get_arrival(y):
    selectStream(select_node_arrival)
    return Exponential(y)

def exit_from_bot():
    selectStream(select_exit_from_bot)
    r = random()
    if r <= p_exit_bot:
        return True
    else:
        return False

def next_event(node_list):
    time_event = []
    for i in range(1, len(node_list)):
        time_event.append(node_list[i].arrival)
        time_event.append(node_list[i].completion)

    time_event = sorted(time_event, key=lambda x: (x is None, x))

    for i in range(1, len(time_event)):
        if time_event[0] == node_list[i].arrival or time_event[0] == node_list[i].completion:
            return i

def select_node(queue_id):
    selectStream(select_node_stream)
    if queue_id:
        r = random()
        for i in range(1, NODES):
            if r <= i / (NODES - 1):
                return i + 1
    return BOT                                # 1 = BOT

def get_service(id_node):
    if id_node == BOT:  # Il bot del call center
        selectStream(select_node_random)
        r = random()
        if r <= p_longer_service:  # Probabilità che un job abbia bisogno di un tempo di servizio maggiore
            selectStream(id_node + select_bot_stream)
            service = Normal(m=1.5, s=0.25)  # Tempo medio 1.5 minuti con deviazione standard di 0.25 minuti
            return service
        else:
            selectStream(id_node + select_bot_stream)
            service = Normal(m=4.0, s=1.0)  # Tempo medio 4 minuti con deviazione standard di 1 minuto
            return service
    else:  # Operatori umani
        selectStream(id_node + select_operator)
        service = Normal(m=7.5, s=2.0)  # Tempo medio 7.5 minuti con deviazione standard di 2 minuti
        return service


def minimum(a, b):
    if a is None and b is not None:
        return b
    elif b is None and a is not None:
        return a
    elif a is None and b is None:
        return None
    elif a < b:
        return a
    else:
        return b



# Funzione di simulazione

def run_simulation(NODES, arrival_time_morning, arrival_time_afternoon, arrival_time_evening, arrival_time_night,
                   select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream,
                   select_exit_from_bot, seed, START, STOP, INFINITY, BOT, p_longer_service, p_exit_bot):

    time = Time()

    # settings
    tempi = [0, 0, 0, 0]
    node_list = [BasicQueue(i) for i in range(NODES + 1)]  # in 0 global stats
    plantSeeds(seed)

    time.current = START
    arrival = START  # global temp var for getArrival function     [minutes]

    # initialization of the first arrival event
    set_arrival_time(arrival_time_morning)
    tempi[3] += 1
    arrival += get_arrival(arrival_time)
    node = node_list[select_node(False)]
    node.arrival = arrival
    min_arrival = arrival
    counter = 0.0

    while (min_arrival < STOP) or (node_list[0].number > 0):

        to_proc = node_list[next_event(node_list)]  # node with minimum arrival or completion time
        time.next = minimum(to_proc.arrival, to_proc.completion)
        # Aggiornamento delle aree basate sul giro prima
        for i in range(0, len(node_list)):
            if node_list[i].number > 0:
                if i != 0:
                    counter += 1
                node_list[i].stat.node += (time.next - time.current) * node_list[i].number
                node_list[i].stat.queue += (time.next - time.current) * (node_list[i].number - 1)
                node_list[i].stat.service += (time.next - time.current)

        current_for_update = time.current
        time.current = time.next  # advance the clock
        # Set arrival time
        day = (time.current / 1440.0) // 1
        current_lambda = time.current - day * 1440.0

        if 480.0 <= current_lambda < 720.0:  # 8-12
            set_arrival_time(arrival_time_morning)
            tempi[0] += 1
        elif 720.0 <= current_lambda < 1020.0:  # 12-17
            set_arrival_time(arrival_time_afternoon)
            tempi[1] += 1
        elif 1020.0 <= current_lambda < 1320.0:  # 17-22
            set_arrival_time(arrival_time_evening)
            tempi[2] += 1
        else:  # 22-8
            set_arrival_time(arrival_time_night)
            tempi[3] += 1
        if time.current == to_proc.arrival:

            to_proc.number += 1
            node_list[0].number += 1  # update system stat
            arrival += get_arrival(arrival_time)
            node_selected_pos = select_node(False)

            # Se il prossimo arrivo è su un altro centro, bisogna eliminare l'arrivo sul centro processato altrimenti
            # sarà sempre il minimo
            if node_selected_pos != to_proc.id:
                to_proc.arrival = INFINITY
            node = node_list[node_selected_pos]

            if node.arrival != INFINITY:
                node.last = node.arrival
                if node.last is not None and node_list[0].last is not None and node_list[0].last < node.last:
                    node_list[0].last = node.last
            # update node and system last arrival time

            if arrival > STOP:
                if node.arrival != INFINITY:
                    node.last = node.arrival
                if node_list[0].last < node.last:
                    node_list[0].last = node.last
                node.arrival = INFINITY
            else:
                node.arrival = arrival

            if to_proc.number == 1:
                to_proc.completion = time.current + get_service(to_proc.id)
        else:
            to_proc.index += 1  # node stats update
            to_proc.number -= 1
            if to_proc.id != BOT:  # system stats update
                node_list[0].index += 1
                node_list[0].number -= 1

            if to_proc.number > 0:
                to_proc.completion = time.current + get_service(to_proc.id)
            else:
                to_proc.completion = INFINITY

            if to_proc.id == BOT:
                if not exit_from_bot():

                    human_node = node_list[select_node(True)]  # on first global stats

                    human_node.number += 1  # system stats don't updated
                    human_node.last = time.current

                    if human_node.number == 1:
                        human_node.completion = time.current + get_service(human_node.id)
                else:
                    node_list[0].index += 1
                    node_list[0].number -= 1

        arrival_list = [node_list[n].arrival for n in range(1, len(node_list))]
        min_arrival = sorted(arrival_list, key=lambda x: (x is None, x))[0]

    print(counter)
    print(tempi)

    for i in range(0, len(node_list)):
        if i == 0:
            total_NODES = NODES  # Il numero totale di nodi nella rete (senza contare il nodo del bot)
            topology_info = f"Single entry queue with {total_NODES} parallel processing nodes."

            print("\n\nAverage system stats")
            print(f"Network topology: {topology_info}")
            print(f"Total jobs processed across all nodes: {node_list[i].index}")
        elif i == BOT:  # Stampa le statistiche per il nodo del bot
            print("\n\nNode " + str(i) + " (Bot)")
        else:
            print("\n\nNode " + str(i))

        print(f"\nfor {node_list[i].index} jobs")

        if node_list[i].index != 0:
            print("   average interarrival time .......... = {0:6.6f} minutes".format(node_list[i].last / node_list[i].index))
            print("   average wait time .................. = {0:6.6f} minutes".format(node_list[i].stat.node / node_list[i].index))
            print("   average delay time ................. = {0:6.6f} minutes".format(node_list[i].stat.queue / node_list[i].index))
            print("   average # in the node .............. = {0:6.6f}".format(node_list[i].stat.node / time.current))
            print("   average # in the queue ............. = {0:6.6f}".format(node_list[i].stat.queue / time.current))
            print("   utilization ........................ = {0:6.6f}".format(node_list[i].stat.service / time.current))
            print(f"   last arrival time .................. = {node_list[i].last} minutes")
