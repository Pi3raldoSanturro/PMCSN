

select_node_stream = 11
select_node_arrival = 10
select_node_random = 23
select_operator = 150
select_bot_stream = 100
select_exit_from_bot = 55

hour_operator_cost = (1100 / 30) / 24  # Costo orario per operatore
daily_operator_cost = hour_operator_cost * 24

b = 128
k = 64

START = 8.0 * 60                                    # Inizio alle ore 8:00
generic_stop = 1 * 1 * 1 * 1440.0 + START           # Anni-Mesi-Giorni-Minuti + orario di inizio
daily_stop = 1440.0 + START                         # Un giorno
weekly_stop = 7 * 1440 + START                      # Una settimana
yearly_stop  = 365 * 1440 + START                   # Un anno 

p_longer_service = 0.6
p_exit_bot = 0.1

nodes = 5  # n nodi

arrival_time = 12.0
arrival_time_morning = 3.8 
arrival_time_afternoon = 4.8  
arrival_time_evening = 6.3
arrival_time_night = 11.0  


BOT = 1

morning_nodes = 12
afternoon_nodes = 7
evening_nodes = 6
night_nodes = 3

replicas = 1
sampling_frequency = 15

