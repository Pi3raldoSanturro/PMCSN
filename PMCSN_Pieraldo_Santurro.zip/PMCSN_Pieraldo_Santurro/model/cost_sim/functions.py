
from utils.rngs import random, selectStream, plantSeeds
from utils.rvgs import Exponential, Normal

from cost_sim.parameters import hour_operator_cost, daily_operator_cost
from cost_sim.parameters import select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream, select_exit_from_bot
from cost_sim.parameters import b,k
from cost_sim.parameters import daily_stop, weekly_stop, yearly_stop, generic_stop, START, nodes
from cost_sim.parameters import p_longer_service, p_exit_bot
from cost_sim.parameters import nodes, arrival_time, arrival_time_morning, arrival_time_afternoon, arrival_time_evening, arrival_time_night
from cost_sim.parameters import replicas, sampling_frequency
from cost_sim.parameters import morning_nodes, afternoon_nodes, evening_nodes, night_nodes, BOT

class Track:
    node = 0.0  
    queue = 0.0  
    service = 0.0  

    def __init__(self):
        self.node = 0.0
        self.queue = 0.0
        self.service = 0.0


class Time:
    current = None  # current time
    next = None  # next (most imminent) event time

class BasicQueue:
    id = None
    arrival = None  # next arrival time
    completion = None  # next completion time
    last = 0.0  # last arrival time
    index = 0.0  # jobs departed
    number = 0.0  # jobs in node
    stat = None
    last_completion = False

    def __init__(self, id_node):
        self.id = id_node
        self.stat = Track()  # Track stats


def set_arrival_time(x):
    global arrival_time
    arrival_time = x


def get_arrival_time():
    return arrival_time


def select_node(queue_id):
    selectStream(select_node_stream)
    if queue_id:
        r = random()
        for i in range(1, nodes):
            if r <= i / (nodes - 1):
                return i + 1
    return BOT


def minimum(a, b):
    if a is None and b is not None:
        return b
    elif b is None and a is not None:
        return a
    elif a is None and b is None:
        return None
    elif a < b:
        return a
    else:
        return b


def get_arrival(y):
    selectStream(select_node_arrival)
    return Exponential(y)

def get_service(id_node):
    if id_node == BOT:  # Il bot del call center
        selectStream(select_node_random)
        r = random()
        if r <= p_longer_service:  # Probabilità che un job abbia bisogno di un tempo di servizio maggiore
            selectStream(id_node + select_bot_stream)
            service = Normal(m=1.5, s=0.25)  # Tempo medio 1.5 minuti con deviazione standard di 0.25 minuti
            return service
        else:
            selectStream(id_node + select_bot_stream)
            service = Normal(m=4.0, s=1.0)  # Tempo medio 4 minuti con deviazione standard di 1 minuto
            return service
    else:  # Operatori umani
        selectStream(id_node + select_operator)
        service = Normal(m=7.5, s=2.0)  # Tempo medio 7.5 minuti con deviazione standard di 2 minuti
        return service
       
def exit_from_bot():
    selectStream(select_exit_from_bot)
    r = random()
    if r <= p_exit_bot:
        return True
    else:
        return False


def online_variance(n, mean, variance, x):
    delta = x - mean
    variance = variance + delta * delta * (n - 1) / n
    mean = mean + delta / n
    return mean, variance