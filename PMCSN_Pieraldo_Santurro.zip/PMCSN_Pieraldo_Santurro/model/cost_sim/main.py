
import os
import csv
from matplotlib import pyplot as plt
import datetime

from utils.rngs import random, selectStream, plantSeeds, getSeed
from utils.rvgs import Exponential, Normal

from cost_sim.functions import Track, Time, BasicQueue
from cost_sim.functions import set_arrival_time, get_arrival_time, select_node, minimum, get_arrival, online_variance, exit_from_bot

from cost_sim.parameters import hour_operator_cost, daily_operator_cost
from cost_sim.parameters import select_node_stream, select_node_arrival, select_node_random, select_operator, select_bot_stream, select_exit_from_bot
from cost_sim.parameters import b,k
from cost_sim.parameters import daily_stop, weekly_stop, yearly_stop, generic_stop, START, nodes
from cost_sim.parameters import p_longer_service, p_exit_bot
from cost_sim.parameters import nodes, arrival_time, arrival_time_morning, arrival_time_afternoon, arrival_time_evening, arrival_time_night
from cost_sim.parameters import replicas, sampling_frequency
from cost_sim.parameters import morning_nodes, afternoon_nodes, evening_nodes, night_nodes, BOT



seeds = [248913709]


STOP = yearly_stop
# STOP = daily_stop
# STOP = weekly_stop

INFINITY = STOP * 100.0


file_dir = os.path.dirname(__file__)
png_dir = os.path.join(file_dir, './images')


def set_arrival_time(x):
    global arrival_time
    arrival_time = x


def get_arrival_time():
    return arrival_time


def select_node(queue_id):
    selectStream(select_node_stream)
    if queue_id:
        r = random()
        for i in range(1, nodes):
            if r <= i / (nodes - 1):
                return i + 1
    return BOT


def minimum(a, b):
    if a is None and b is not None:
        return b
    elif b is None and a is not None:
        return a
    elif a is None and b is None:
        return None
    elif a < b:
        return a
    else:
        return b


def get_arrival(y):
    selectStream(select_node_arrival)
    return Exponential(y)

       
def exit_from_bot():
    selectStream(select_exit_from_bot)
    r = random()
    if r <= p_exit_bot:
        return True
    else:
        return False


def online_variance(n, mean, variance, x):
    delta = x - mean
    variance = variance + delta * delta * (n - 1) / n
    mean = mean + delta / n
    return mean, variance


time = Time()


def next_event():
    time_event = []
    for i in range(1, len(node_list)):
        time_event.append(node_list[i].arrival)
        time_event.append(node_list[i].completion)

    time_event = sorted(time_event, key=lambda x: (x is None, x))

    for i in range(1, len(time_event)):
        if time_event[0] == node_list[i].arrival or time_event[0] == node_list[i].completion:
            return i

def get_service(id_node):
    if id_node == BOT:  # Il bot 
        selectStream(select_node_random)
        r = random()
        if r <= p_longer_service:  # Probabilità che un job abbia bisogno di un tempo di servizio maggiore
            selectStream(id_node + select_bot_stream)
            service = Normal(m=1.5, s=0.25)  # Tempo medio 1.5 minuti con deviazione standard di 0.25 minuti
            return service
        else:
            selectStream(id_node + select_bot_stream)
            service = Normal(m=4.0, s=1.0)  # Tempo medio 4 minuti con deviazione standard di 1 minuto
            return service
    else:  # Operatori umani
        selectStream(id_node + select_operator)
        service = Normal(m=7.5, s=2.0)  # Tempo medio 7.5 minuti con deviazione standard di 2 minuti
        return service

def cost_calculator(stop, morning_nodes, afternoon_nodes, evening_nodes, night_nodes):
    """
    Calcola il costo totale degli operatori umanoidi considerando gli aumenti per orari notturni e giorni festivi.

    :param stop: Durata della simulazione in minuti (STOP)
    :param morning_nodes: Numero di operatori umanoidi attivi nella fascia mattutina
    :param afternoon_nodes: Numero di operatori umanoidi attivi nella fascia pomeridiana
    :param evening_nodes: Numero di operatori umanoidi attivi nella fascia serale
    :param night_nodes: Numero di operatori umanoidi attivi nella fascia notturna
    :return: Costo totale per tutti gli operatori umanoidi per la durata della simulazione
    """

    # Costo base per operatore
    hour_operator_cost = 6.73  # Costo orario per operatore
    cost_per_minute = hour_operator_cost / 60  # Costo per minuto per operatore

    # Aumento dei costi per notturno e festivi
    night_shift_multiplier = 1.3  # 30% in più per turni notturni
    weekend_multiplier = 1.3  # 30% in più per sabato e domenica
    holiday_multiplier = 1.5  # 50% in più per i giorni festivi

    # Giorni festivi italiani (esempio per l'anno 2024)
    italian_holidays = [
        datetime.date(2024, 1, 1),  # Capodanno
        datetime.date(2024, 4, 1),  # Pasquetta
        datetime.date(2024, 4, 25),  # Festa della Liberazione
        datetime.date(2024, 5, 1),  # Festa dei Lavoratori
        datetime.date(2024, 6, 2),  # Festa della Repubblica
        datetime.date(2024, 8, 15), # Ferragosto
        datetime.date(2024, 12, 25), # Natale
        datetime.date(2024, 12, 26)  # Santo Stefano
    ]

    # Definizione dei giorni per ciascun mese in un anno (non considerando gli anni bisestili)
    days_in_month = {
        'Gennaio': 31, 'Febbraio': 28, 'Marzo': 31, 'Aprile': 30,
        'Maggio': 31, 'Giugno': 30, 'Luglio': 31, 'Agosto': 31,
        'Settembre': 30, 'Ottobre': 31, 'Novembre': 30, 'Dicembre': 31
    }

    # Calcola il numero di giorni richiesti dalla simulazione in base al valore di stop
    total_days = stop / 1440  # Converte la durata della simulazione da minuti a giorni
    print("Total days of Sim:" + str(total_days))

    # Funzione per calcolare il costo per giorno
    def calculate_daily_cost(date, base_cost, night_cost):
        if date.weekday() == 5 or date.weekday() == 6:  # Sabato o Domenica
            daily_cost = base_cost * weekend_multiplier + night_cost * weekend_multiplier
        elif date in italian_holidays:  # Giorno festivo
            daily_cost = base_cost * holiday_multiplier + night_cost * holiday_multiplier
        else:  # Giorno normale
            daily_cost = base_cost + night_cost
        return daily_cost

    # Se la simulazione dura meno di 5 giorni, non considerare alcun giorno festivo
    if  total_days < 6:
        base_cost = (morning_nodes * 4 * 60 + afternoon_nodes * 5 * 60 + evening_nodes * 5 * 60) * cost_per_minute
        night_cost = night_nodes * 10 * 60 * cost_per_minute * night_shift_multiplier
        total_cost = total_days * (base_cost + night_cost)
        print(f"Simulazione per {total_days:.2f}")

    elif total_days > 6 and total_days < 8:
        # Considera solo il sabato e/o domenica
        total_cost = 0
        current_day = datetime.date.today()
        for day in range(int(total_days)):
            cost_for_day = calculate_daily_cost(current_day, 
                                                (morning_nodes * 4 * 60 + afternoon_nodes * 5 * 60 + evening_nodes * 5 * 60) * cost_per_minute, 
                                                night_nodes * 10 * 60 * cost_per_minute * night_shift_multiplier)
            total_cost += cost_for_day
            current_day += datetime.timedelta(days=1)
        print(f"Simulazione per {total_days:.2f}")

    elif total_days >=  365:
        # Simulazione su base annuale
        total_cost = 0
        start_date = datetime.date(2024, 1, 1)
        for month, days in days_in_month.items():
            monthly_cost = 0
            for day in range(days):
                current_date = start_date + datetime.timedelta(days=day)
                monthly_cost += calculate_daily_cost(current_date, 
                                                     (morning_nodes * 4 * 60 + afternoon_nodes * 5 * 60 + evening_nodes * 5 * 60) * cost_per_minute, 
                                                     night_nodes * 10 * 60 * cost_per_minute * night_shift_multiplier)
            total_cost += monthly_cost
            print(f"Costo per il mese di {month}: {monthly_cost:.2f} EUR")
            start_date += datetime.timedelta(days=days)

        print("Simulazione annuale completata.")

    print("\nCOSTO TOTALE PER LA SIMULAZIONE: " + str(total_cost))
    return total_cost




def calculate_total_operator_cost(STOP, morning_nodes, afternoon_nodes, evening_nodes, night_nodes, cost_per_hour):
    """
    Calcola il costo totale degli operatori umanoidi per la durata della simulazione.

    :param STOP: Durata della simulazione in minuti
    :param morning_nodes: Numero di operatori umanoidi attivi nella fascia mattutina
    :param afternoon_nodes: Numero di operatori umanoidi attivi nella fascia pomeridiana
    :param evening_nodes: Numero di operatori umanoidi attivi nella fascia serale
    :param night_nodes: Numero di operatori umanoidi attivi nella fascia notturna
    :param cost_per_hour: Costo per operatore per ora
    :return: Costo totale per tutti gli operatori umanoidi per la durata della simulazione
    """
    # Converti il costo degli operatori da orario a minutario
    cost_per_minute = cost_per_hour / 60

    # Converti la durata della simulazione da minuti a giorni
    days = STOP / (1440)

    # Calcola il costo totale per ciascuna fascia oraria per tutti i giorni
    morning_cost = days * morning_nodes * 4 * 60 * cost_per_minute  # 4 ore (8:00 - 12:00)
    afternoon_cost = days * afternoon_nodes * 5 * 60 * cost_per_minute  # 5 ore (12:00 - 17:00)
    evening_cost = days * evening_nodes * 5 * 60 * cost_per_minute  # 5 ore (17:00 - 22:00)
    night_cost = days * night_nodes * 10 * 60 * cost_per_minute  # 10 ore (22:00 - 8:00)

    # Somma dei costi totali per ciascuna fascia oraria
    total_cost = morning_cost + afternoon_cost + evening_cost + night_cost

    print("\nCosto totale degli operatori al mattino:"+ str(morning_cost))
    print("\nCosto totale degli operatori nel pomeriggio:"+ str(afternoon_cost))
    print("\nCosto totale degli operatori di sera :"+ str(evening_cost))
    print("\nCosto totale degli operatori di notte:"+ str(night_cost))


    print("\n\nCOSTO TOTALE:" + str(total_cost))

    return total_cost


def plot_average_wait():
    fig, ax = plt.subplots(figsize=(16, 9), dpi=400) 
    x = dictionary_structure_list[0]["time_current"]
    colors = ['red', 'royalblue', 'green', 'lawngreen', 'lightseagreen', 'orange', 'blueviolet']
    
    ax.set_ylim([0, 60])
    ax.set_ylabel(ylabel="Average wait system (minutes)", fontsize=15)
    ax.tick_params(labelsize=10)
        
    if STOP == daily_stop:
        ax.vlines(480, 0, 60, color='lawngreen', label="")
        ax.vlines(720, 0, 60, color='blue', label="")
        ax.vlines(1020, 0, 60, color='red', label="")
        ax.vlines(1320, 0, 60, color='orange', label="")

        ax.legend(["08:00", "12:00", "17:00", "22:00"])

    elif (STOP == weekly_stop or STOP == yearly_stop):
        if STOP == weekly_stop:
            days = 7
            for day in range (0,days):
                ax.vlines(day*1440+START,0,60,color = 'red', label = "")
            ax.legend(["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"])
        if STOP == yearly_stop:
            tot_month = 12
            for month in range (0,tot_month):
                ax.vlines(month*30*1440+START,0,60,color = 'red', label = "")
            ax.legend(["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre","Novembre", "Dicembre"])
    
    total_avg_wait_system = 0
    for i in range(0, len(dictionary_structure_list)):
        # Filtra i valori None dalla lista avg_wait_system
        valid_wait_times = [time for time in dictionary_structure_list[i]["avg_wait_system"] if time is not None]
        if valid_wait_times:  # Assicurati che la lista non sia vuota
            avg_wait_system = sum(valid_wait_times) / len(valid_wait_times)
            total_avg_wait_system += avg_wait_system
            # Tronca x per far corrispondere la lunghezza a quella di valid_wait_times
            truncated_x = x[:len(valid_wait_times)]
            plt.plot(truncated_x, valid_wait_times, 'o', color=colors[i % len(colors)], label=dictionary_structure_list[i]["seed"], mfc='none')
    
    if not os.path.exists(png_dir):
        os.makedirs(png_dir)
    plt.savefig(fname= png_dir + "/average_wait.png", bbox_inches='tight')
    plt.close(fig)
    
    return total_avg_wait_system / len(dictionary_structure_list)


# def plot_average_wait():
#     fig, ax = plt.subplots(figsize=(16, 9), dpi=400) 
#     x = dictionary_structure_list[0]["time_current"]
#     colors = ['red', 'royalblue', 'green', 'lawngreen', 'lightseagreen', 'orange', 'blueviolet']
    
#     ax.set_ylim([0, 60])
#     ax.set_ylabel(ylabel="Average wait system (minutes)", fontsize=15)
#     ax.tick_params(labelsize=10)
        
#     if STOP == daily_stop:
#         ax.vlines(480, 0, 60, color='lawngreen', label="")
#         ax.vlines(720, 0, 60, color='blue', label="")
#         ax.vlines(1020, 0, 60, color='red', label="")
#         ax.vlines(1320, 0, 60, color='orange', label="")

#         ax.legend(["08:00", "12:00", "17:00", "22:00"])

#     elif (STOP == weekly_stop or STOP == yearly_stop):
#         if STOP == weekly_stop:
#             days = 7
#             for day in range (0,days):
#                 ax.vlines(day*1440+START,0,60,color = 'red', label = "")
#             ax.legend(["Lunedì", "Martedì", "Mercoledì", "Giovedì", "Venerdì", "Sabato", "Domenica"])
#         if STOP == yearly_stop:
#             tot_month = 12
#             for month in range (0,tot_month):
#                 ax.vlines(month*30*1440+START,0,60,color = 'red', label = "")
#             ax.legend(["Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre","Novembre", "Dicembre"])

    
#     # Grafico dell'average wait system per ciascun seed
#     for i in range(0, len(dictionary_structure_list)):
#         # ax.plot(x, [dictionary_structure_list[i]["avg_wait_system"][j] for j in range(0, len(dictionary_structure_list[i]["avg_wait_system"]))],
#         #         'o', color=colors[i], label=dictionary_structure_list[i]["seed"], mfc='none')
#         plt.plot(x, [dictionary_structure_list[i]["avg_wait_system"][j] for j in range(len(dictionary_structure_list[i]["avg_wait_system"]))],
#                  'o', color=colors[i % len(colors)], label=dictionary_structure_list[i]["seed"], mfc='none')
    
#     if not os.path.exists(png_dir):
#         os.makedirs(png_dir)
#     plt.savefig(fname= png_dir + "/average_wait.png", bbox_inches='tight')
#     plt.close(fig)


def print_simulation_info(STOP, n1, n2, n3, n4, avg_wait_system):
    """
    Stampa le informazioni richieste relative alla simulazione.

    :param STOP: Durata della simulazione in minuti
    :param n1: Numero di nodi nella fascia mattutina
    :param n2: Numero di nodi nella fascia pomeridiana
    :param n3: Numero di nodi nella fascia serale
    :param n4: Numero di nodi nella fascia notturna
    :param avg_wait_system: Valore medio del tempo di attesa nel sistema
    """
    print(f"Valore di STOP: {STOP} minuti")
    print(f"Numero di nodi operatori - Mattina: {n1-1}, Pomeriggio: {n2-1}, Sera: {n3-1}, Notte: {n4-1}")
    print(f"Valore medio di avg_wait_system: {avg_wait_system:.2f} minuti")



def redirect_jobs(nodi_prec):

    if nodi_prec == nodes:
        return
    if nodi_prec < nodes:  # 2-->3

        iteration_count = nodes - nodi_prec
        for i in range(2, nodi_prec + 1):
            if node_list[i].number > 1:
                n_jobs = node_list[i].number
                for jobs in range(0, int(n_jobs) - 1):
                    pos = select_node(True)
                    node_list[pos].number += 1
                    if node_list[pos].number == 1:
                        node_list[pos].completion = time.current + get_service(node_list[pos].id)
                    node_list[i].number -= 1

        return

    if nodi_prec > nodes:
        iteration_count = nodi_prec - nodes  # 3-->2
        for i in range(nodes + 1, nodes + 1 + iteration_count):
            if node_list[i].number > 1:
                n_jobs = node_list[i].number
                for jobs in range(0, int(n_jobs) - 1):
                    pos = select_node(True)
                    node_list[pos].number += 1
                    if node_list[pos].number == 1:
                        node_list[pos].completion = time.current + get_service(node_list[pos].id)
                    node_list[i].number -= 1
            if node_list[i].arrival != INFINITY and node_list[
                i].arrival is not None:  
                pos = select_node(True)
                node_list[pos].arrival = node_list[i].arrival

            node_list[i].arrival = None

            if node_list[i].number == 1:
                node_list[i].last_completion = True
        return


def stats_del(i):
    node_list[i].number = 0.0 
    node_list[i].last = 0.0
    node_list[i].completion = None
    node_list[i].index = 0.0
    node_list[i].stat.node = 0.0
    node_list[i].stat.queue = 0.0
    node_list[i].stat.service = 0.0
    node_list[i].last_completion = False


dictionary_structure_list = []


if __name__ == '__main__':

    if (STOP == daily_stop):
        sampling_frequency = 10
    elif (STOP == weekly_stop):
        sampling_frequency = 50
    elif (STOP == yearly_stop):
        sampling_frequency = 110
    else:
        sampling_frequency = 75

    n1 = morning_nodes
    n2 = afternoon_nodes
    n3 = evening_nodes
    n4 = night_nodes
    
    for seed in seeds:
        batch_means_info_struct = {
            "seed": 0,
            "n_nodes": 0,
            "lambda": 0.0,
            "b": 0,
            "k": 0,
            "time_current": [i * sampling_frequency + START for i in
                             range(0, int((STOP - START) / sampling_frequency) + 1)],
            "job_list": [None] * (int((STOP - START) / sampling_frequency) + 1),
            "avg_wait_bot_node": [None] * (int((STOP - START) / sampling_frequency) + 1), 
            "std_dev_bot_node": [None] * (int((STOP - START) / sampling_frequency) + 1),
            "avg_delay_human_nodes": [None] * (int((STOP - START) / sampling_frequency) + 1),
            "st_dev_human_nodes": [None] * (int((STOP - START) / sampling_frequency) + 1),
            "avg_wait_system": [None] * (int((STOP - START) / sampling_frequency) + 1),
            "st_dev_total_sys": [None] * (int((STOP - START) / sampling_frequency) + 1),
        }
        batch_means_info = batch_means_info_struct
        batch_means_info["seed"] = seed
        batch_means_info["b"] = b
        batch_means_info["k"] = k
        batch_means_info["n_nodes"] = nodes - 1
        batch_means_info["lambda"] = 1.0 / arrival_time
        node_list = [BasicQueue(i) for i in range(max(n1, n2, n3, n4) + 1)]

        plantSeeds(seed)

        for replica in range(0, replicas):
            job_list = []
            batch_means_info["job_list"] = job_list
            for center in node_list:
                center.number = 0.0
                center.last = 0.0
                center.arrival = None
                center.completion = None
                center.index = 0.0
                center.stat.node = 0.0
                center.stat.queue = 0.0
                center.stat.service = 0.0

            batch_index = 0
            time.current = START
            arrival = START  
            sampling = START 
            sampling_count = 0
            set_arrival_time(arrival_time_morning)
            nodes = n1
            arrival += get_arrival(arrival_time)
            node = node_list[select_node(False)]
            node.arrival = arrival
            min_arrival = arrival
            old_index = 0

            while min_arrival < STOP:

                if time.current - sampling > sampling_frequency:
                    step = int((time.current - sampling) / sampling_frequency)

                    if batch_means_info["avg_wait_bot_node"][sampling_count + step - 1] is None:
                        if len(job_list) == 0:
                            batch_means_info["avg_wait_bot_node"][sampling_count + step - 1] = 0.0
                            batch_means_info["std_dev_bot_node"][sampling_count + step - 1] = 0.0
                            batch_means_info["avg_delay_human_nodes"][sampling_count + step - 1] = 0.0
                            batch_means_info["st_dev_human_nodes"][sampling_count + step - 1] = 0.0
                            batch_means_info["avg_wait_system"][sampling_count + step - 1] = 0.0
                            batch_means_info["st_dev_total_sys"][sampling_count + step - 1] = 0.0
                        else:
                            batch_means_info["avg_wait_bot_node"][sampling_count + step - 1] = job_list[-1]["wait_bot"]
                            batch_means_info["std_dev_bot_node"][sampling_count + step - 1] = 0.0
                            batch_means_info["avg_delay_human_nodes"][sampling_count + step - 1] = job_list[-1]["delay_human_nodes"]
                            batch_means_info["st_dev_human_nodes"][sampling_count + step - 1] = 0.0
                            batch_means_info["avg_wait_system"][sampling_count + step - 1] = job_list[-1]["wait_system"]
                            batch_means_info["st_dev_total_sys"][sampling_count + step - 1] = 0.0

                    else:
                        if len(job_list) != 0:
                            batch_means_info["avg_wait_bot_node"][sampling_count + step - 1], \
                            batch_means_info["std_dev_bot_node"][sampling_count + step - 1] = online_variance(replica + 1,
                                                                                                        batch_means_info["avg_wait_bot_node"][sampling_count + step - 1],
                                                                                                        batch_means_info["std_dev_bot_node"][sampling_count + step - 1],
                                                                                                        job_list[- 1]["wait_bot"])
                            batch_means_info["avg_delay_human_nodes"][sampling_count + step - 1], \
                            batch_means_info["st_dev_human_nodes"][sampling_count + step - 1] = online_variance(replica + 1,
                                                                                                         batch_means_info["avg_delay_human_nodes"][sampling_count + step - 1],
                                                                                                         batch_means_info["st_dev_human_nodes"][sampling_count + step - 1],
                                                                                                         job_list[- 1]["delay_human_nodes"])
                            batch_means_info["avg_wait_system"][sampling_count + step - 1], \
                            batch_means_info["st_dev_total_sys"][sampling_count + step - 1] = online_variance(replica + 1,
                                                                                                        batch_means_info["avg_wait_system"][sampling_count + step - 1],
                                                                                                        batch_means_info["st_dev_total_sys"][sampling_count + step - 1],
                                                                                                        job_list[- 1]["wait_system"])
                    sampling_count += step
                    sampling = START + (sampling_frequency * (sampling_count + 1))

                node_to_process = node_list[next_event()]  
                time.next = minimum(node_to_process.arrival, node_to_process.completion)
                for i in range(0, len(node_list)):
                    if node_list[i].number > 0:
                        node_list[i].stat.node += (time.next - time.current) * node_list[i].number
                        node_list[i].stat.queue += (time.next - time.current) * (node_list[i].number - 1)
                        node_list[i].stat.service += (time.next - time.current)

                current_for_update = time.current
                time.current = time.next 

                day = (time.current / 1440.0) // 1
                current_lambda = time.current - day * 1440.0

                if 480.0 <= current_lambda < 720.0:  # 8-12
                    set_arrival_time(arrival_time_morning)
                    nodi_prec = nodes
                    nodes = n1
                    redirect_jobs(nodi_prec)
                elif 720.0 <= current_lambda < 1020.0:  # 12-17
                    set_arrival_time(arrival_time_afternoon)
                    nodi_prec = nodes
                    nodes = n2
                    redirect_jobs(nodi_prec)
                elif 1020.0 <= current_lambda < 1320.0:  # 17-22
                    set_arrival_time(arrival_time_evening)
                    nodi_prec = nodes
                    nodes = n3
                    redirect_jobs(nodi_prec)
                else:  # 22-8
                    set_arrival_time(arrival_time_night)
                    nodi_prec = nodes
                    nodes = n4
                    redirect_jobs(nodi_prec)

                if time.current == node_to_process.arrival:
                    node_to_process.number += 1
                    node_list[0].number += 1 
                    arrival += get_arrival(arrival_time)
                    node_selected_pos = select_node(False)
                    if node_selected_pos != node_to_process.id:
                        node_to_process.arrival = INFINITY
                    node = node_list[node_selected_pos]

                    if node.arrival != INFINITY:
                        node.last = node.arrival
                        if node.last is not None and node_list[0].last is not None and node_list[0].last < node.last:
                            node_list[0].last = node.last

                    if arrival > STOP:
                        if node.arrival != INFINITY:
                            node.last = node.arrival
                            if node.last is not None and node_list[0].last is not None and node_list[0].last < node.last:
                                node_list[0].last = node.last
                        node.arrival = INFINITY
                    else:
                        node.arrival = arrival

                    if node_to_process.number == 1:
                        node_to_process.completion = time.current + get_service(node_to_process.id)

                else:
                    node_to_process.index += 1
                    node_to_process.number -= 1
                    if node_to_process.id != BOT:  
                        node_list[0].index += 1
                        node_list[0].number -= 1
                        actual_stats = {
                            "wait_bot": 0.0,
                            "delay_human_nodes": 0.0,
                            "wait_system": 0.0
                        }
                        act_st = actual_stats
                        if node_list[0].index != 0:
                            act_st["wait_system"] = node_list[0].stat.node / node_list[0].index
                        if node_list[1].index != 0:
                            act_st["wait_bot"] = node_list[1].stat.node / node_list[1].index
                        delay_human_nodes_avg = 0.0
                        for i in range(2, nodes + 1):
                            if node_list[i].index != 0:
                                delay_human_nodes_avg += (node_list[i].stat.queue / node_list[i].index)
                        delay_human_nodes_avg = delay_human_nodes_avg / (nodes - 1.0)
                        act_st["delay_human_nodes"] = delay_human_nodes_avg
                        job_list.append(act_st)
                        if node_to_process.last_completion is True:
                            stats_del(node_to_process.id)

                    if node_to_process.number > 0:
                        node_to_process.completion = time.current + get_service(node_to_process.id)
                    else:
                        node_to_process.completion = INFINITY

                    if node_to_process.id == BOT:  
                        if not exit_from_bot():
                            human_node = node_list[select_node(True)] 
                            human_node.number += 1 
                            human_node.last = time.current

                            if human_node.number == 1:
                                human_node.completion = time.current + get_service(human_node.id)
                        else:
                            node_list[0].index += 1
                            node_list[0].number -= 1

                arrival_list = [node_list[n].arrival for n in range(1, max(n1, n2, n3, n4) + 1)]
                min_arrival = sorted(arrival_list, key=lambda x: (x is None, x))[0]

        if len(seeds) <= 5 :
            new_seed = getSeed()
            seeds.append(new_seed)

        dictionary_structure_list.append(batch_means_info)

        # Directory per i file CSV
        csv_dir = os.path.join(file_dir, './csv')

        # Estrai la directory dal percorso
        directory = os.path.dirname(csv_dir)

        # Controlla se la directory esiste, in caso contrario, creala
        if not os.path.exists(csv_dir):
            os.makedirs(csv_dir)

        # Definisci i nomi dei campi per il file CSV
        fieldnames = list(batch_means_info.keys())

        # Apri il file CSV e scrivi i dati
        path = os.path.join(csv_dir, "stats_" + str(seed) + ".csv")
        with open(path, 'w', newline='') as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow(batch_means_info)

    avg_wait_system_value = plot_average_wait()
    print_simulation_info(STOP, n1, n2, n3, n4, avg_wait_system_value)
    # plot_average_wait()
    cost_calculator(STOP, n1-1, n2-1, n3-1, n4-1)
